<!DOCTYPE HTML>
<html>
    <head>
        <title>EtuServices - Accueil</title>
        <style>
            /* Adding some styles to make the webpage more visually appealing */
            body {
                font-family: Arial, sans-serif;
                text-align: center;
                padding: 50px;
            }
            h1 {
                font-size: 2em;
                margin-bottom: 20px;
            }
            a {
                text-decoration: none;
                color: blue;
            }
        </style>
    </head>
    <body>
        <h1>Bienvenue sur EtuServices</h1>
        <p>Vous pouvez vous connecter en cliquant <a href="login.php">ici</a></p>
    </body>
</html>
