<!DOCTYPE html>
<html>
<head>
    <title>EtuServices</title>
    <style>
        body {
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Welcome to EtuServices</h1>
    <p>We apologize that our services are currently under development.</p>
    <a href="login.php">Return to Homepage</a>
</body>
</html>
